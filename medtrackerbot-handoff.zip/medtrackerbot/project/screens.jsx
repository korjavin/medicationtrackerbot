// Screens: Today, Blood Pressure, Food Intake + Edit modal.

// ============================================================
// TODAY (home dashboard)
// ============================================================
const TodayScreen = ({ go }) => {
  const t = window.TODAY_SUMMARY;
  const bpSpark = window.BP_READINGS.slice(-14).map(r => r.sys);
  const hrSpark = [74, 76, 72, 78, 80, 75, 79, 82, 77, 88, 90, 85, 95, 97];
  const foodPct = (t.kcal / t.kcalTarget) * 100;

  return (
    <div className="page">
      {/* Next action card - sun, compact */}
      <div className="card" style={{background:'linear-gradient(180deg,rgba(251,189,13,0.18) 0%,rgba(251,189,13,0.06) 100%)', borderColor:'rgba(251,189,13,0.3)', marginBottom:10, padding:'10px 12px'}}>
        <div className="row gap-3" style={{alignItems:'center'}}>
          <div style={{width:34,height:34,borderRadius:10,background:'rgba(251,189,13,0.2)',border:'1px solid rgba(251,189,13,0.4)', display:'flex',alignItems:'center',justifyContent:'center',color:'#FBBD0D', flexShrink:0}}>
            <Icon name="pill" size={17}/>
          </div>
          <div className="flex-1" style={{minWidth:0}}>
            <div style={{fontSize:9.5,letterSpacing:'0.14em',textTransform:'uppercase',color:'rgba(251,189,13,0.85)',fontWeight:600}}>Next · 08:20 · in 1h 21m</div>
            <div style={{fontFamily:'JetBrains Mono',fontSize:13,color:'#F4FBF7',marginTop:1, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>Allopurinol · Bisoprolol · +4</div>
          </div>
          <button className="gloss gloss-sun" style={{padding:'7px 12px', fontSize:12, flexShrink:0}} onClick={() => go('meds')}>Take</button>
        </div>
      </div>

      {/* Metric grid */}
      <div className="section-label" style={{padding:'10px 4px 6px'}}><span><span className="accent-dot"/>Vitals</span><span className="muted" style={{fontSize:10}}>Tap to open</span></div>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:8}}>
        <MetricTile
          label="Blood pressure"
          value={<>{t.bp.sys}<span className="muted" style={{fontSize:18}}>/{t.bp.dia}</span></>}
          unit="mmHg"
          status={<span className="tag tag-high">High-normal</span>}
          spark={bpSpark} color="#FBBD0D"
          onClick={() => go('bp')}
        />
        <MetricTile
          label="Heart rate"
          value={<>{t.pulse}</>}
          unit="bpm"
          status={<span className="tag tag-normal">Resting</span>}
          spark={hrSpark} color="#F3A693"
          onClick={() => go('bp')}
        />
        <MetricTile
          label="SpO₂"
          value={<>{t.spo2}<span className="muted" style={{fontSize:14}}>%</span></>}
          unit="30d avg 95"
          status={<span className="tag tag-normal">Normal</span>}
          spark={[95,96,97,96,95,97,96,96,97,95,97,97,96,97]} color="#9CE4CC"
          onClick={() => go('more')}
        />
        <MetricTile
          label="Weight"
          value={<>{t.weight}</>}
          unit="kg"
          status={<span className="tag tag-normal">↓ 0.4 wk</span>}
          spark={[85.2,84.9,85.0,84.8,84.6,84.5,84.6,84.4,84.5,84.3,84.4,84.2,84.3,84.2]} color="#9CE4CC"
          onClick={() => go('more')}
        />
      </div>

      {/* Food today */}
      <div className="section-label" style={{padding:'10px 4px 6px'}}><span><span className="accent-dot"/>Fuel today</span><span className="muted" style={{fontSize:10}}>4 items</span></div>
      <div className="card" onClick={() => go('food')} style={{cursor:'pointer', padding:'10px 12px'}}>
        <div className="row" style={{justifyContent:'space-between', alignItems:'baseline'}}>
          <div>
            <div className="mono-display" style={{fontSize:22, lineHeight:1}}>{t.kcal}<span className="muted" style={{fontSize:12,fontFamily:'Space Grotesk', marginLeft:4}}>/ {t.kcalTarget} kcal</span></div>
            <div className="muted" style={{fontSize:10.5, letterSpacing:'0.04em', marginTop:2}}>C:4 · P:73 · F:73</div>
          </div>
          <div style={{textAlign:'right'}}>
            <div style={{fontFamily:'JetBrains Mono',fontSize:16,color:'#FBBD0D', lineHeight:1}}>{Math.round(foodPct)}%</div>
            <div className="muted" style={{fontSize:9.5, letterSpacing:'0.08em', textTransform:'uppercase', marginTop:2}}>of target</div>
          </div>
        </div>
        <div style={{marginTop:10, display:'flex', flexDirection:'column', gap:4}}>
          <MiniBar label="Energy"  pct={foodPct} color="#FBBD0D"/>
          <MiniBar label="Protein" pct={48.6}   color="#9CE4CC"/>
          <MiniBar label="Carbs"   pct={2.4}    color="#56AC8A"/>
          <MiniBar label="Fat"     pct={91.2}   color="#E5A600"/>
        </div>
      </div>

      {/* Workout + Sleep row */}
      <div className="section-label" style={{padding:'10px 4px 6px'}}><span><span className="accent-dot"/>Today's plan</span></div>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:8}}>
        <div className="card" style={{padding:'10px 11px'}}>
          <div style={{display:'flex', alignItems:'center', gap:6, marginBottom:6}}>
            <Icon name="dumbbell" size={14}/>
            <div style={{fontSize:9.5, letterSpacing:'0.14em', textTransform:'uppercase', color:'rgba(244,251,247,0.6)', fontWeight:600}}>Workout</div>
          </div>
          <div style={{fontFamily:'JetBrains Mono', fontSize:13, color:'#F4FBF7', lineHeight:1.1}}>Evening 2</div>
          <div className="muted" style={{fontSize:10.5, marginTop:2}}>PULL · 18:00</div>
        </div>
        <div className="card" style={{padding:'10px 11px'}}>
          <div style={{display:'flex', alignItems:'center', gap:6, marginBottom:6}}>
            <Icon name="moon" size={14}/>
            <div style={{fontSize:9.5, letterSpacing:'0.14em', textTransform:'uppercase', color:'rgba(244,251,247,0.6)', fontWeight:600}}>Sleep</div>
          </div>
          <div style={{fontFamily:'JetBrains Mono', fontSize:13, color:'#F4FBF7', lineHeight:1.1}}>7h 42m</div>
          <div className="muted" style={{fontSize:10.5, marginTop:2}}>00:18 → 08:00</div>
        </div>
      </div>

      {/* Streak */}
      <div className="section-label" style={{padding:'10px 4px 6px'}}><span><span className="accent-dot"/>Consistency</span></div>
      <div className="card" style={{padding:'10px 12px'}}>
        <div className="row" style={{justifyContent:'space-between', alignItems:'center'}}>
          <div>
            <div style={{fontFamily:'JetBrains Mono',fontSize:18,color:'#FBBD0D', letterSpacing:'-0.02em', lineHeight:1}}>14 <span style={{color:'rgba(244,251,247,0.6)',fontSize:11, letterSpacing:0}}>day streak</span></div>
            <div className="muted" style={{fontSize:10.5, marginTop:3}}>All vitals logged, 2 weeks running</div>
          </div>
          <div style={{display:'flex',gap:3}}>
            {Array.from({length:14}).map((_, i) => (
              <div key={i} style={{width:5, height:14+Math.sin(i)*3, borderRadius:2, background: i > 10 ? '#FBBD0D' : 'rgba(156,228,204,0.65)'}}/>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const MetricTile = ({ label, value, unit, status, spark, color, onClick }) => (
  <button className="card" style={{padding:'9px 10px', textAlign:'left', background:'linear-gradient(180deg,rgba(255,255,255,0.04) 0%,rgba(0,0,0,0) 60%), #254844', border:'1px solid rgba(255,255,255,0.06)', cursor:'pointer', width:'100%', color:'inherit'}} onClick={onClick}>
    <div style={{fontSize:9.5, letterSpacing:'0.12em', textTransform:'uppercase', color:'rgba(244,251,247,0.5)', fontWeight:600}}>{label}</div>
    <div style={{fontFamily:'JetBrains Mono', fontSize:20, fontWeight:500, letterSpacing:'-0.02em', color:'#F4FBF7', marginTop:3, lineHeight:1}}>{value}</div>
    <div className="muted" style={{fontSize:9.5, marginTop:2, fontFamily:'Space Grotesk'}}>{unit}</div>
    <div style={{marginTop:4, marginBottom:4, marginLeft:-2}}>
      <Sparkline points={spark} color={color} width={150} height={22}/>
    </div>
    <div>{status}</div>
  </button>
);

const MiniBar = ({ label, pct, color }) => (
  <div className="row gap-3" style={{alignItems:'center'}}>
    <div style={{width:48, fontSize:11, fontWeight:600, color:'rgba(244,251,247,0.75)'}}>{label}</div>
    <div style={{flex:1, height:6, background:'rgba(0,0,0,0.35)', borderRadius:999, boxShadow:'inset 0 1px 2px rgba(0,0,0,0.4)', overflow:'hidden'}}>
      <div style={{width:`${Math.min(pct,100)}%`, height:'100%', background:color, borderRadius:999, boxShadow:`0 0 6px ${color}`}}/>
    </div>
    <div style={{width:40, fontFamily:'JetBrains Mono', fontSize:10, color:'rgba(244,251,247,0.6)', textAlign:'right'}}>{Math.round(pct)}%</div>
  </div>
);

// ============================================================
// BLOOD PRESSURE
// ============================================================
const BPScreen = ({ go }) => {
  const readings = window.BP_READINGS;
  const [range, setRange] = React.useState(60);

  const avgOver = (days) => {
    const slice = readings.slice(-days * 2);
    const sys = Math.round(slice.reduce((s,r) => s+r.sys, 0) / slice.length);
    const dia = Math.round(slice.reduce((s,r) => s+r.dia, 0) / slice.length);
    return { sys, dia, n: slice.length };
  };
  const avg14 = avgOver(14);
  const avg30 = avgOver(30);
  const avg60 = avgOver(60);

  const fmtTime = (iso) => {
    const d = new Date(iso);
    return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
  };
  const fmtDate = (iso) => {
    const d = new Date(iso);
    const today = new Date(2026, 3, 20);
    const diff = Math.floor((today - d) / (1000*60*60*24));
    if (diff === 0) return 'Today';
    if (diff === 1) return 'Yesterday';
    return `${String(d.getDate()).padStart(2,'0')}.${String(d.getMonth()+1).padStart(2,'0')}.${d.getFullYear()}`;
  };

  const groupedByDay = {};
  readings.slice().reverse().forEach(r => {
    const key = fmtDate(r.date);
    if (!groupedByDay[key]) groupedByDay[key] = [];
    groupedByDay[key].push(r);
  });

  const statusTag = (r) => {
    if (r.sys >= 140 || r.dia >= 90) return <span className="tag tag-alert">High</span>;
    if (r.sys >= 130 || r.dia >= 85) return <span className="tag tag-high">Stage 1</span>;
    if (r.sys >= 120 || r.dia >= 80) return <span className="tag tag-high">High-normal</span>;
    return <span className="tag tag-normal">Normal</span>;
  };

  const shownReadings = readings.slice(-range * 2);

  return (
    <div className="page">
      {/* Big current reading */}
      <div className="card" style={{padding:'18px 16px', marginBottom:14}}>
        <div className="row" style={{justifyContent:'space-between', alignItems:'flex-start'}}>
          <div>
            <div style={{fontSize:10.5, letterSpacing:'0.14em', textTransform:'uppercase', color:'rgba(244,251,247,0.5)', fontWeight:600}}>Latest · today 08:12</div>
            <div style={{marginTop:6, fontFamily:'JetBrains Mono', fontSize:44, fontWeight:500, letterSpacing:'-0.03em', color:'#F4FBF7', lineHeight:1}}>
              132<span style={{color:'rgba(244,251,247,0.35)'}}>/70</span>
            </div>
            <div style={{marginTop:8, display:'flex', gap:6, alignItems:'center'}}>
              <span className="tag tag-high">High-normal</span>
              <span className="muted" style={{fontSize:11}}>· 76 bpm</span>
            </div>
          </div>
          <button className="gloss gloss-sun" style={{padding:'10px 14px', fontSize:12, display:'flex', alignItems:'center', gap:6}}>
            <Icon name="plus" size={14}/>Log
          </button>
        </div>
      </div>

      {/* Range selector */}
      <div style={{display:'flex', gap:6, marginBottom:10}}>
        {[{d:14,l:'14d'},{d:30,l:'30d'},{d:60,l:'60d'}].map(o => (
          <button key={o.d} className="gloss" onClick={() => setRange(o.d)} style={{flex:1, padding:'8px', fontSize:12, background: range === o.d ? undefined : 'linear-gradient(180deg, rgba(255,255,255,0.04) 0%, rgba(0,0,0,0) 50%), #1F3F3B', boxShadow: range === o.d ? undefined : 'inset 0 1px 0 rgba(255,255,255,0.04)'}}>
            {o.l}
          </button>
        ))}
      </div>

      {/* Chart */}
      <div className="card chart-card">
        <BPChart readings={shownReadings}/>
      </div>

      {/* Averages */}
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, marginTop:12}}>
        {[{l:'14d', v:avg14},{l:'30d', v:avg30},{l:'60d', v:avg60}].map(a => (
          <div key={a.l} className="card" style={{padding:10, textAlign:'center'}}>
            <div style={{fontSize:9.5, letterSpacing:'0.14em', textTransform:'uppercase', color:'rgba(244,251,247,0.45)', fontWeight:600}}>{a.l} avg</div>
            <div style={{fontFamily:'JetBrains Mono', fontSize:18, color:'#F4FBF7', marginTop:4, letterSpacing:'-0.02em'}}>{a.v.sys}<span style={{color:'rgba(244,251,247,0.35)'}}>/{a.v.dia}</span></div>
          </div>
        ))}
      </div>

      {/* History list */}
      {Object.entries(groupedByDay).slice(0, 4).map(([day, rs]) => (
        <div key={day}>
          <div className="section-label">{day}</div>
          {rs.map((r, i) => (
            <div key={i} className="card" style={{padding:'12px 14px', marginBottom:8, display:'flex', alignItems:'center', gap:12}}>
              <div className="flex-1">
                <div style={{fontFamily:'JetBrains Mono', fontSize:20, fontWeight:500, color:'#F4FBF7', letterSpacing:'-0.02em', lineHeight:1}}>
                  {r.sys}<span style={{color:'rgba(244,251,247,0.35)'}}>/{r.dia}</span>
                </div>
                <div style={{display:'flex', gap:8, alignItems:'center', marginTop:6, fontSize:11}}>
                  <span className="muted mono">{fmtTime(r.date)}</span>
                  <span className="tag tag-mono" style={{background:'rgba(255,255,255,0.04)', color:'rgba(244,251,247,0.6)', borderColor:'rgba(255,255,255,0.08)'}}>{r.pulse} bpm</span>
                  {statusTag(r)}
                </div>
              </div>
              <button className="icon-btn" aria-label="Delete">
                <div className="gloss" style={{width:36, height:36, borderRadius:10, display:'flex', alignItems:'center', justifyContent:'center'}}>
                  <Icon name="trash" size={15}/>
                </div>
              </button>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

// ============================================================
// FOOD INTAKE
// ============================================================
const FoodScreen = ({ go, onEdit }) => {
  const t = window.FOOD_TARGETS;
  const items = window.FOOD_LOG;
  const totals = items.reduce((s, x) => ({
    kcal: s.kcal + x.kcal, c: s.c + x.c, p: s.p + x.p, f: s.f + x.f
  }), {kcal:0, c:0, p:0, f:0});

  const pct = {
    energy: (totals.kcal / t.energy) * 100,
    protein: (totals.p / t.protein) * 100,
    carbs: (totals.c / t.carbs) * 100,
    fat: (totals.f / t.fat) * 100,
  };

  return (
    <div className="page">
      {/* Tabs */}
      <div style={{display:'flex', gap:4, marginBottom:14, padding:4, background:'linear-gradient(180deg, #1F3F3B 0%, #264742 100%)', borderRadius:12, border:'1px solid rgba(0,0,0,0.25)', boxShadow:'inset 0 2px 4px rgba(0,0,0,0.3)'}}>
        {['Daily log', 'My meals', 'Food DB'].map((t, i) => (
          <button key={t} style={{flex:1, padding:'8px 10px', fontSize:11.5, fontFamily:'Space Grotesk', fontWeight:600, color: i === 0 ? '#1a1200' : 'rgba(244,251,247,0.6)', background: i === 0 ? 'linear-gradient(180deg, #FFD14A 0%, #E5A600 100%)' : 'transparent', border:'none', borderRadius:9, cursor:'pointer', boxShadow: i === 0 ? 'inset 0 1px 0 rgba(255,255,255,0.5), 0 1px 0 rgba(0,0,0,0.15)' : 'none'}}>
            {t}
          </button>
        ))}
      </div>

      {/* Day navigator */}
      <div className="row" style={{justifyContent:'space-between', marginBottom:12}}>
        <button className="icon-btn"><div className="gloss" style={{width:36,height:36,borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center'}}><Icon name="chevronLeft" size={16}/></div></button>
        <div style={{textAlign:'center'}}>
          <div style={{fontFamily:'JetBrains Mono', fontSize:16, fontWeight:500, color:'#F4FBF7', letterSpacing:'-0.01em'}}>Today</div>
          <div className="muted" style={{fontSize:10.5, letterSpacing:'0.1em', textTransform:'uppercase', marginTop:2}}>20.04.2026</div>
        </div>
        <button className="icon-btn"><div className="gloss" style={{width:36,height:36,borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center'}}><Icon name="chevronRight" size={16}/></div></button>
      </div>

      {/* Macros card */}
      <div className="card" style={{padding:'16px 14px'}}>
        <div className="row" style={{justifyContent:'space-between', alignItems:'baseline', marginBottom:14}}>
          <div>
            <div style={{fontSize:10.5, letterSpacing:'0.14em', textTransform:'uppercase', color:'rgba(244,251,247,0.5)', fontWeight:600}}>Daily total</div>
            <div style={{fontFamily:'JetBrains Mono', fontSize:30, fontWeight:500, color:'#F4FBF7', letterSpacing:'-0.03em', lineHeight:1, marginTop:4}}>
              {totals.kcal}<span style={{fontSize:14, color:'rgba(244,251,247,0.45)', marginLeft:6}}>kcal</span>
            </div>
          </div>
          <div style={{textAlign:'right'}}>
            <div style={{fontFamily:'JetBrains Mono', fontSize:22, color:'#FBBD0D', letterSpacing:'-0.02em'}}>{Math.round(pct.energy)}%</div>
            <div className="muted" style={{fontSize:10, letterSpacing:'0.08em', textTransform:'uppercase', marginTop:1}}>of target</div>
          </div>
        </div>

        <div style={{display:'flex', flexDirection:'column', gap:9}}>
          <MacroRow label="Energy"  value={totals.kcal} target={t.energy}  unit="kcal" color="#FBBD0D"/>
          <MacroRow label="Protein" value={totals.p}    target={t.protein} unit="g"    color="#9CE4CC"/>
          <MacroRow label="Carbs"   value={totals.c}    target={t.carbs}   unit="g"    color="#56AC8A"/>
          <MacroRow label="Fat"     value={totals.f}    target={t.fat}     unit="g"    color="#E5A600"/>
        </div>
      </div>

      {/* Meal group */}
      <div className="section-label" style={{flexWrap:'nowrap', gap:8}}>
        <span style={{whiteSpace:'nowrap'}}><span className="accent-dot"/>Snack · 00:46</span>
        <span className="mono" style={{color:'rgba(244,251,247,0.6)', fontSize:10.5, whiteSpace:'nowrap'}}>{totals.kcal} kcal</span>
      </div>

      {items.map((it) => (
        <div key={it.id} className="card" style={{padding:'12px 14px', marginBottom:8, display:'flex', alignItems:'center', gap:8}}>
          <div className="flex-1" style={{minWidth:0}}>
            <div style={{fontFamily:'Space Grotesk', fontSize:14, fontWeight:500, color:'#F4FBF7', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>{it.name}</div>
            <div style={{display:'flex', gap:6, alignItems:'center', marginTop:4, whiteSpace:'nowrap'}}>
              <span className="mono" style={{fontSize:11, color:'rgba(244,251,247,0.55)'}}>{it.grams}g</span>
              <span style={{fontSize:11, color:'rgba(244,251,247,0.3)'}}>·</span>
              <span className="mono" style={{fontSize:11, color:'#FBBD0D'}}>{it.kcal} kcal</span>
              <span style={{fontSize:11, color:'rgba(244,251,247,0.3)'}}>·</span>
              <span className="muted mono" style={{fontSize:10}}>P{it.p} F{it.f}</span>
            </div>
          </div>
          <button className="icon-btn" onClick={() => onEdit(it)} aria-label="Edit" style={{flexShrink:0}}>
            <div className="gloss" style={{width:34, height:34, borderRadius:10, display:'flex', alignItems:'center', justifyContent:'center'}}>
              <Icon name="pencil" size={14}/>
            </div>
          </button>
          <button className="icon-btn" aria-label="Delete" style={{flexShrink:0}}>
            <div className="gloss" style={{width:34, height:34, borderRadius:10, display:'flex', alignItems:'center', justifyContent:'center'}}>
              <Icon name="trash" size={14}/>
            </div>
          </button>
        </div>
      ))}

      {/* Add meal CTA */}
      <button className="gloss gloss-sun" style={{width:'100%', padding:'14px', marginTop:10, display:'flex', alignItems:'center', justifyContent:'center', gap:8, fontSize:14}} onClick={() => onEdit({name:'',grams:100,kcal:0,c:0,p:0,f:0,isNew:true})}>
        <Icon name="plus" size={16}/>Add food
      </button>
    </div>
  );
};

const MacroRow = ({ label, value, target, unit, color }) => {
  const pct = Math.min((value / target) * 100, 100);
  return (
    <div style={{display:'grid', gridTemplateColumns:'56px 1fr auto', gap:10, alignItems:'center'}}>
      <div style={{fontSize:11.5, fontWeight:600, color:'rgba(244,251,247,0.85)'}}>{label}</div>
      <div style={{height:8, background:'linear-gradient(180deg, #1F3F3B 0%, #264742 100%)', borderRadius:999, boxShadow:'inset 0 2px 3px rgba(0,0,0,0.4)', overflow:'hidden'}}>
        <div style={{width:`${pct}%`, height:'100%', background:color, borderRadius:999, boxShadow:`inset 0 1px 0 rgba(255,255,255,0.3), 0 0 6px ${color}`, transition:'width 400ms cubic-bezier(.2,.7,.2,1)'}}/>
      </div>
      <div style={{minWidth:72, textAlign:'right', fontFamily:'JetBrains Mono', fontSize:11, color:'rgba(244,251,247,0.65)'}}>
        {value} <span style={{color:'rgba(244,251,247,0.35)'}}>/ {target} {unit}</span>
      </div>
    </div>
  );
};

// ============================================================
// EDIT FOOD MODAL
// ============================================================
const EditFoodModal = ({ item, onClose, onSave }) => {
  const [grams, setGrams] = React.useState(item.grams || 100);
  const [name, setName] = React.useState(item.name || '');
  const [c, setC] = React.useState(item.c || 0);
  const [p, setP] = React.useState(item.p || 0);
  const [f, setF] = React.useState(item.f || 0);
  const [kcal, setKcal] = React.useState(item.kcal || 0);

  const InputWrap = ({ label, children, flex = 1 }) => (
    <div style={{flex}}>
      <div style={{fontSize:10, letterSpacing:'0.14em', textTransform:'uppercase', color:'rgba(244,251,247,0.5)', fontWeight:600, marginBottom:6}}>{label}</div>
      {children}
    </div>
  );
  const inputStyle = {
    width:'100%', padding:'10px 12px', borderRadius:10,
    background:'linear-gradient(180deg, #1F3F3B 0%, #264742 100%)',
    border:'1px solid rgba(0,0,0,0.25)',
    boxShadow:'inset 0 2px 4px rgba(0,0,0,0.35)',
    color:'#F4FBF7', fontFamily:'JetBrains Mono', fontSize:14, outline:'none',
    boxSizing:'border-box',
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="row" style={{justifyContent:'space-between', alignItems:'center', marginBottom:16}}>
          <div style={{display:'flex', flexDirection:'column', gap:4, minWidth:0}}>
            <div style={{fontSize:10.5, letterSpacing:'0.14em', textTransform:'uppercase', color:'rgba(244,251,247,0.45)', fontWeight:600, lineHeight:1}}>{item.isNew ? 'New entry' : 'Edit entry'}</div>
            <div style={{fontFamily:'JetBrains Mono', fontSize:18, color:'#F4FBF7', letterSpacing:'-0.01em', lineHeight:1.1}}>Food</div>
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="Close">
            <div className="gloss" style={{width:36,height:36,borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center'}}>
              <Icon name="close" size={15}/>
            </div>
          </button>
        </div>

        <div style={{display:'flex', gap:10, marginBottom:14}}>
          <InputWrap label="Weight (g)" flex={1}>
            <input type="number" value={grams} onChange={e => setGrams(+e.target.value)} style={inputStyle}/>
          </InputWrap>
          <InputWrap label="Barcode" flex={2}>
            <div style={{display:'flex', gap:6}}>
              <input type="text" placeholder="e.g. 1234567890" style={{...inputStyle, flex:1, fontSize:12}}/>
              <button className="gloss" style={{padding:'10px 12px', fontSize:12, display:'flex', alignItems:'center', gap:4}}>
                <Icon name="barcode" size={14}/>Scan
              </button>
            </div>
          </InputWrap>
        </div>

        <InputWrap label="Food name">
          <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. wagyu kebab" style={{...inputStyle, marginBottom:14}}/>
        </InputWrap>

        <div style={{fontSize:10.5, letterSpacing:'0.14em', textTransform:'uppercase', color:'rgba(244,251,247,0.55)', fontWeight:600, marginBottom:8, marginTop:4}}>Macros · per 100g</div>
        <div style={{display:'flex', gap:10, marginBottom:14}}>
          <InputWrap label="Carbs">
            <input type="number" value={c} onChange={e => setC(+e.target.value)} style={inputStyle}/>
          </InputWrap>
          <InputWrap label="Protein">
            <input type="number" value={p} onChange={e => setP(+e.target.value)} style={inputStyle}/>
          </InputWrap>
          <InputWrap label="Fat">
            <input type="number" value={f} onChange={e => setF(+e.target.value)} style={inputStyle}/>
          </InputWrap>
        </div>

        <InputWrap label="Total calories">
          <input type="number" value={kcal} onChange={e => setKcal(+e.target.value)} style={{...inputStyle, marginBottom:14, fontSize:18}}/>
        </InputWrap>

        <InputWrap label="Date & time">
          <input type="text" defaultValue="20.04.2026, 00:46" style={{...inputStyle, marginBottom:18}}/>
        </InputWrap>

        <div style={{display:'flex', gap:8}}>
          <button className="gloss" style={{flex:1, padding:'12px', fontSize:13}} onClick={onClose}>Cancel</button>
          <button className="gloss gloss-sun" style={{flex:2, padding:'12px', fontSize:13}} onClick={() => onSave({grams, name, c, p, f, kcal})}>Save entry</button>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// Simple placeholder screens
// ============================================================
const PlaceholderScreen = ({ title }) => (
  <div className="page">
    <div className="card" style={{padding:30, textAlign:'center'}}>
      <div style={{fontFamily:'JetBrains Mono', fontSize:16, color:'#F4FBF7', marginBottom:6}}>{title}</div>
      <div className="muted" style={{fontSize:12}}>Not included in this round</div>
    </div>
  </div>
);

Object.assign(window, { TodayScreen, BPScreen, FoodScreen, EditFoodModal, PlaceholderScreen });
