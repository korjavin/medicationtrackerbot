// Synthetic health data for the MedTracker prototype.

// BP readings — 60 days, two per day, ending today (20.04.2026).
// Realistic-ish drift: mostly normal/high-normal, a few spikes near the end.
window.BP_READINGS = (() => {
  const readings = [];
  const today = new Date(2026, 3, 20, 9, 0, 0);
  const rand = (seed) => {
    // deterministic pseudo-random
    const x = Math.sin(seed * 12.9898) * 43758.5453;
    return x - Math.floor(x);
  };
  let sysBase = 118;
  let diaBase = 74;
  for (let d = 59; d >= 0; d--) {
    for (let s = 0; s < 2; s++) {
      const seed = d * 2 + s;
      const day = new Date(today); day.setDate(today.getDate() - d);
      day.setHours(s === 0 ? 8 : 20, Math.floor(rand(seed) * 60));
      // late-period drift
      const drift = d < 7 ? (7 - d) * 1.2 : 0;
      const spike = (d === 1 || d === 2) && s === 0 ? 10 : 0;
      const sys = Math.round(sysBase + (rand(seed) - 0.5) * 14 + drift + spike);
      const dia = Math.round(diaBase + (rand(seed + 99) - 0.5) * 10 + drift * 0.4);
      const pulse = Math.round(68 + (rand(seed + 17) - 0.5) * 16);
      let status = 'normal';
      if (sys >= 140 || dia >= 90) status = 'high';
      else if (sys >= 130 || dia >= 85) status = 'high2';
      else if (sys >= 120 || dia >= 80) status = 'highnormal';
      readings.push({ sys, dia, pulse, date: day.toISOString(), status });
    }
  }
  return readings;
})();

window.FOOD_TARGETS = { energy: 1800, protein: 150, carbs: 165, fat: 80 };

window.FOOD_LOG = [
  { id: 'f1', meal: 'Snack', time: '00:46', name: 'wagyu kebab', grams: 100, kcal: 215, c: 0, p: 20, f: 15 },
  { id: 'f2', meal: 'Snack', time: '00:46', name: 'mixed vegetables', grams: 50, kcal: 12, c: 2, p: 1, f: 0 },
  { id: 'f3', meal: 'Snack', time: '00:48', name: 'salmon belly', grams: 200, kcal: 430, c: 0, p: 32, f: 34 },
  { id: 'f4', meal: 'Snack', time: '00:50', name: 'sausage', grams: 100, kcal: 308, c: 2, p: 20, f: 24 },
];

window.TODAY_SUMMARY = {
  bp: { sys: 132, dia: 70, time: '08:12', status: 'high' },
  pulse: 76,
  hr7: 97,
  hr30: 92,
  spo2: 97,
  weight: 84.2,
  weightTrend: -0.4,
  kcal: 965,
  kcalTarget: 1800,
  meds: { taken: 6, total: 7, nextIn: '1h 21m', nextAt: '08:20' },
  workout: { name: 'Evening 2 — PULL', when: 'Today · 18:00', status: 'scheduled' },
  streak: 14,
};
