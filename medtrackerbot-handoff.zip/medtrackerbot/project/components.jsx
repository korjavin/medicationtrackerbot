// Shared icons, chart, and small UI bits.

const Icon = ({ name, size = 20, stroke = 1.8 }) => {
  const props = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const paths = {
    chevronLeft: <path d="m15 18-6-6 6-6" />,
    chevronRight: <path d="m9 18 6-6-6-6" />,
    chevronDown: <path d="m6 9 6 6 6-6" />,
    plus: <path d="M12 5v14M5 12h14" />,
    more: <g><circle cx="12" cy="5" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="12" cy="19" r="1.3"/></g>,
    trash: <g><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M6 6l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/></g>,
    pencil: <g><path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></g>,
    heart: <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>,
    drop: <path d="M12 2.69 17.66 8.35a8 8 0 1 1-11.32 0z"/>,
    pill: <g><path d="M10.5 20.5a7.07 7.07 0 0 1-10-10l10-10a7.07 7.07 0 0 1 10 10Z"/><path d="m8.5 8.5 7 7"/></g>,
    apple: <g><path d="M12 7c0-3 2-5 4-5-1 2-2 3-4 5Z"/><path d="M17 7c3 0 5 3 5 6 0 5-4 10-6 10-1 0-2-1-4-1s-3 1-4 1c-2 0-6-5-6-10 0-3 2-6 5-6 2 0 3 1 5 1s2-1 5-1z"/></g>,
    activity: <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>,
    home: <g><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/></g>,
    calendar: <g><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></g>,
    chart: <g><path d="M3 3v18h18"/><path d="m7 14 4-4 4 4 6-6"/></g>,
    bolt: <path d="M13 2 3 14h9l-1 8 10-12h-9z"/>,
    bell: <g><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></g>,
    dumbbell: <g><path d="M6 4v16M18 4v16M2 8v8M22 8v8M6 12h12"/></g>,
    check: <path d="M20 6 9 17l-5-5"/>,
    close: <path d="M18 6 6 18M6 6l12 12"/>,
    barcode: <g><path d="M3 5v14M7 5v14M11 5v14M15 5v14M19 5v14"/></g>,
    moon: <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>,
    footprints: <g><path d="M4 16v-4a2 2 0 1 1 4 0v4M14 16v-6a2 2 0 1 1 4 0v6"/><circle cx="6" cy="20" r="2"/><circle cx="16" cy="20" r="2"/></g>,
    scale: <g><rect x="3" y="7" width="18" height="14" rx="2"/><path d="M7 11h10M12 11v4"/></g>,
    target: <g><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/></g>,
    clock: <g><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></g>,
    back: <path d="m15 18-6-6 6-6"/>,
  };
  return <svg {...props}>{paths[name]}</svg>;
};

// ─── Status bar ───
const StatusBar = () => (
  <div className="status-bar">
    <span>9:41</span>
    <div className="icons">
      <svg width="17" height="11" viewBox="0 0 17 11" fill="currentColor">
        <rect x="0" y="7" width="3" height="4" rx="0.6"/>
        <rect x="4.5" y="5" width="3" height="6" rx="0.6"/>
        <rect x="9" y="2.5" width="3" height="8.5" rx="0.6"/>
        <rect x="13.5" y="0" width="3" height="11" rx="0.6"/>
      </svg>
      <svg width="16" height="11" viewBox="0 0 16 11" fill="currentColor">
        <path d="M8 2C10 2 11.8 2.8 13.2 4L14.1 3.1C12.5 1.5 10.3 0.5 8 0.5C5.7 0.5 3.5 1.5 1.9 3.1L2.8 4C4.2 2.8 6 2 8 2Z"/>
        <path d="M8 5.5C9.2 5.5 10.3 6 11.1 6.8L12 5.9C10.9 4.8 9.5 4.1 8 4.1C6.5 4.1 5.1 4.8 4 5.9L4.9 6.8C5.7 6 6.8 5.5 8 5.5Z"/>
        <circle cx="8" cy="9" r="1.4"/>
      </svg>
      <svg width="26" height="12" viewBox="0 0 26 12" fill="none">
        <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke="currentColor" strokeOpacity="0.5"/>
        <rect x="2" y="2" width="19" height="8" rx="1.5" fill="currentColor"/>
        <path d="M24 3.5v5c0.7-0.3 1.3-1.1 1.3-1.75V5.25c0-0.65-0.6-1.45-1.3-1.75z" fill="currentColor" fillOpacity="0.5"/>
      </svg>
    </div>
  </div>
);

// ─── Header (teal stage with gloss back) ───
const AppHeader = ({ title, subtitle, onBack, actions, showBack = true }) => (
  <div className="app-header">
    {showBack ? (
      <button className="icon-btn" onClick={onBack} aria-label="Back">
        <div className="gloss"><Icon name="back" size={18}/></div>
      </button>
    ) : <div/>}
    <div className="title">
      {title}
      {subtitle && <small>{subtitle}</small>}
    </div>
    <div>
      {actions || (
        <button className="icon-btn" aria-label="More">
          <div className="gloss"><Icon name="more" size={18}/></div>
        </button>
      )}
    </div>
  </div>
);

// ─── BP chart (SVG, responsive, mobile) ───
const BPChart = ({ readings, style = 'band' }) => {
  const W = 358, H = 200;
  const PAD_L = 28, PAD_R = 14, PAD_T = 14, PAD_B = 26;
  const plotW = W - PAD_L - PAD_R;
  const plotH = H - PAD_T - PAD_B;
  const yMin = 50, yMax = 160;
  const xOf = (i) => PAD_L + (i / (readings.length - 1)) * plotW;
  const yOf = (v) => PAD_T + plotH - ((v - yMin) / (yMax - yMin)) * plotH;

  const sysPath = readings.map((r, i) => `${i === 0 ? 'M' : 'L'}${xOf(i).toFixed(1)} ${yOf(r.sys).toFixed(1)}`).join(' ');
  const diaPath = readings.map((r, i) => `${i === 0 ? 'M' : 'L'}${xOf(i).toFixed(1)} ${yOf(r.dia).toFixed(1)}`).join(' ');
  const bandPath = `${sysPath} L${xOf(readings.length - 1)} ${yOf(readings[readings.length - 1].dia)} ${readings.slice().reverse().map((r, i) => `L${xOf(readings.length - 1 - i).toFixed(1)} ${yOf(r.dia).toFixed(1)}`).join(' ')} Z`;

  const yTicks = [60, 80, 100, 120, 140];
  const first = readings[0], last = readings[readings.length - 1];
  const fmtDate = (iso) => {
    const d = new Date(iso);
    return `${String(d.getDate()).padStart(2,'0')}.${String(d.getMonth()+1).padStart(2,'0')}.`;
  };

  const dotColor = (r) => {
    if (r.sys >= 140 || r.dia >= 90) return '#E56B4A';
    if (r.sys >= 130 || r.dia >= 85) return '#FBBD0D';
    return '#56AC8A';
  };

  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{width: '100%', height: 'auto', display: 'block'}}>
      {/* gridlines */}
      {yTicks.map(y => (
        <g key={y}>
          <line x1={PAD_L} x2={W - PAD_R} y1={yOf(y)} y2={yOf(y)} stroke="rgba(255,255,255,0.06)" strokeWidth="1" strokeDasharray={y === 120 || y === 80 ? '3 3' : ''}/>
          <text x={PAD_L - 6} y={yOf(y) + 3} textAnchor="end" fill="rgba(244,251,247,0.4)" fontSize="9" fontFamily="JetBrains Mono">{y}</text>
        </g>
      ))}
      {/* Normal band 80-120 */}
      <rect x={PAD_L} y={yOf(120)} width={plotW} height={yOf(80) - yOf(120)} fill="rgba(86,172,138,0.06)" />
      {/* Band between sys and dia */}
      {style === 'band' && <path d={bandPath} fill="rgba(156,228,204,0.08)" />}
      {/* Sys line */}
      <path d={sysPath} fill="none" stroke="#9CE4CC" strokeWidth="1.4" strokeLinejoin="round" opacity="0.85"/>
      {/* Dia line */}
      <path d={diaPath} fill="none" stroke="#56AC8A" strokeWidth="1.4" strokeLinejoin="round" opacity="0.85"/>
      {/* Dots for last 14 days */}
      {readings.slice(-28).map((r, idx) => {
        const i = readings.length - 28 + idx;
        return (
          <g key={i}>
            <circle cx={xOf(i)} cy={yOf(r.sys)} r="2" fill={dotColor(r)} />
            <circle cx={xOf(i)} cy={yOf(r.dia)} r="1.6" fill={dotColor(r)} opacity="0.7"/>
          </g>
        );
      })}
      {/* End labels */}
      <circle cx={xOf(readings.length - 1)} cy={yOf(last.sys)} r="4" fill="#FBBD0D" stroke="#2D544F" strokeWidth="1.5"/>
      <circle cx={xOf(readings.length - 1)} cy={yOf(last.dia)} r="4" fill="#FBBD0D" stroke="#2D544F" strokeWidth="1.5"/>
      <text x={xOf(readings.length - 1) - 4} y={yOf(last.sys) - 8} textAnchor="end" fill="#FBBD0D" fontSize="10" fontFamily="JetBrains Mono" fontWeight="500">{last.sys}</text>
      <text x={xOf(readings.length - 1) - 4} y={yOf(last.dia) + 14} textAnchor="end" fill="#FBBD0D" fontSize="10" fontFamily="JetBrains Mono" fontWeight="500">{last.dia}</text>
      {/* x-axis labels */}
      <text x={PAD_L} y={H - 6} fill="rgba(244,251,247,0.42)" fontSize="9" fontFamily="Space Grotesk">{fmtDate(first.date)}</text>
      <text x={W - PAD_R} y={H - 6} textAnchor="end" fill="rgba(244,251,247,0.42)" fontSize="9" fontFamily="Space Grotesk">{fmtDate(last.date)}</text>
    </svg>
  );
};

// ─── Sparkline ───
const Sparkline = ({ points, color = '#9CE4CC', width = 80, height = 30, fill = true }) => {
  if (!points || points.length === 0) return null;
  const min = Math.min(...points), max = Math.max(...points);
  const range = max - min || 1;
  const xs = (i) => (i / (points.length - 1)) * width;
  const ys = (v) => height - 2 - ((v - min) / range) * (height - 4);
  const d = points.map((v, i) => `${i === 0 ? 'M' : 'L'}${xs(i).toFixed(1)} ${ys(v).toFixed(1)}`).join(' ');
  const fillPath = `${d} L${width} ${height} L0 ${height} Z`;
  return (
    <svg width={width} height={height} style={{display:'block'}}>
      {fill && <path d={fillPath} fill={color} opacity="0.14"/>}
      <path d={d} fill="none" stroke={color} strokeWidth="1.4" strokeLinejoin="round" strokeLinecap="round"/>
      <circle cx={xs(points.length - 1)} cy={ys(points[points.length - 1])} r="2.3" fill={color}/>
    </svg>
  );
};

// ─── Bottom nav ───
const BottomNav = ({ active, onChange }) => {
  const items = [
    { id: 'today', label: 'Today', icon: 'home' },
    { id: 'bp', label: 'Bp', icon: 'activity' },
    { id: 'food', label: 'Food', icon: 'apple' },
    { id: 'meds', label: 'Meds', icon: 'pill' },
    { id: 'more', label: 'More', icon: 'more' },
  ];
  return (
    <div className="bottom-nav">
      <div className="bottom-nav-inner">
        {items.map(it => (
          <button key={it.id} className={`nav-item ${active === it.id ? 'active' : ''}`} onClick={() => onChange(it.id)}>
            <Icon name={it.icon} size={20}/>
            <span>{it.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

Object.assign(window, { Icon, StatusBar, AppHeader, BPChart, Sparkline, BottomNav });
